package hitam.epics.sahaya.support;

/**
 * Created by sanjit on 22/5/17.
 */

public class CurriculumVList {
    long uid;
    String name;
}
