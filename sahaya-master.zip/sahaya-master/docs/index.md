# Sahaya

## About The Community Partner - Sahaya

Sahaya provides an opportunity to individuals who want to make a positive impact in the society by empowering, enriching and encouraging under-priviliged school going children

## [Download Sahaya App](https://play.google.com/store/apps/details?id=hitam.epics.sahaya) (Uninstall Previous Version, if Installed)

<hr/>

## Team Members

* Sanjit Singh Chouhan
* Pattan Asif Khan
* T Sri Yeswanth Sharma

<hr/>

## Project Tasks

1. [Recognition of community partner](https://hitam-epics.github.io/sahaya/EPICS-Sanjit-Asif-Yeswanth.txt)
2. [Team Roles and Schedules](https://hitam-epics.github.io/sahaya/EPICS-Sanjit-Asif-Yeswanth 2.txt)
3. [Product Survey](https://hitam-epics.github.io/sahaya/Product Survey.txt)
4. [**Review 1**](https://hitam-epics.github.io/sahaya/holy knights epics review 1.pdf)
5. [**Review 2 - PPT**](https://hitam-epics.github.io/sahaya/Sahaya - HKH ppt2.pdf)
6. [**Review 2 - Documentation**](https://hitam-epics.github.io/sahaya/Documentation - HKH.pdf)

<hr/>

## Updates(Recent On Top)

### (APP) Release 1 - 26 Feb 2017

### (APP) Announcements - 23 Feb 2017

#### (APP) Admin Panel - Events and Roles - 14 Feb 2017

#### (APP) UI Change - 21 Jan 2017

#### (APP) Admin Panel and Dashboard UI Change - 20 Jan 2017

#### (APP) Login Bug Fix and UserType Intialisation - 19 Jan 2017

#### (APP) Login Through Facebook - 13 Jan 2017

#### (APP) Profile Picture - 12 Jan 2017

#### (APP) Removed Discussion Forum Bug - 08 Jan 2017

#### (APP) Push Notifications for Discussion forum - 05 Jan 2017

#### (APP) Discussion and Timetable - 05 Jan 2017

#### (APP) Discussion(bug) - 05 Jan 20

#### (APP)Authentications - 18 Dec 2016

#### (APP)Initial Commit - 17 Dec 2016

#### Meeting With Sahaya - 17 Dec 2016
Our team had a meeting with sahaya team
