package hitam.epics.sahaya.support;

/**
 * Created by sanjit on 20/1/17.
 */

public class UserData {
    public static UserType userType;

    public enum UserType {
        ADMIN, VOLUNTEER
    }
}
